import os
import numpy as np
import pandas as pd
import igraph as ig
import time
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec


d = 3
n = 200
length = 10

rho1 = 1.09
gamma1 = 0.06
alpha1 = 0.13
poss1 = 0.05
beta1 = 10**(-7)


BASE_SAVE = r"C:/Users/Lenovo/Desktop/PastState/Lorenz/NetworkAnalysis/Data"
os.makedirs(BASE_SAVE, exist_ok=True)

data = pd.read_excel("C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx")
T = data["time"].to_numpy()
X = data["x"].to_numpy()
Y = data["y"].to_numpy()
Z = data["z"].to_numpy()

t_ini = T[:int(length / 0.01)]
x_ini = X[:int(length / 0.01)]
y_ini = Y[:int(length / 0.01)]
z_ini = Z[:int(length / 0.01)]
t_train = (T[int(length / 0.01)-1:int(length / 0.01)+4000]) / 1.014
x_train = X[int(length / 0.01)-1:int(length / 0.01)+4000]
y_train = Y[int(length / 0.01)-1:int(length / 0.01)+4000]
z_train = Z[int(length / 0.01)-1:int(length / 0.01)+4000]
V = np.array([x_train, y_train, z_train])
V1 = np.array([x_ini, y_ini, z_ini])


def nn(point, data):
    s = np.dot(point, data)
    index = np.argmax(s)
    nearest_nei = data[:, index]
    return nearest_nei, index


def Lorenz_Pred(k):
    Index = np.zeros(len(t_train) - 1)
    r2 = np.zeros((n, len(t_train)))
    r1 = np.zeros((n, len(t_train)))
    for _ in range(1):
        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))

        Win = np.random.uniform(-gamma1, gamma1, (n, d))
        A_ = ig.Graph.Erdos_Renyi(n=n, p=poss1)
        A_.es['weight'] = np.random.normal(0, 1, len(A_.es))
        A = np.array(A_.get_adjacency(attribute='weight').data)
        rhoA = max(np.linalg.eig(A)[0])
        A = (rho1 / abs(rhoA)) * A

        WinV1 = np.dot(Win, V1)
        for h in range(len(t_ini) - 1):
            R1[:, h + 1] = (1 - alpha1) * R1[:, h] + \
                           alpha1 * np.tanh(np.dot(A, R1[:, h]) + WinV1[:, h])
        R[:, 0] = R1[:, -1]
        R1 = R1[:, 500:]

        WinV = np.dot(Win, V)
        for i in range(len(t_train) - 1):
            Nearest_R, num = nn(R[:, i], R1)
            Index[i] = num           # Used Reference State Index
            r2[:, i] = Nearest_R     # Used Reference State
            R[:, i + 1] = (1 - alpha1) * R[:, i] + \
                          alpha1 * np.tanh(np.dot(A, Nearest_R) + WinV[:, i])
        r1 += R

    return r1, r2, Index     # R_tra, R_np, Index


def Lorenz_Pred_RC(k):
    r1 = np.zeros((n, len(t_train)))
    for _ in range(1):
        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))

        Win = np.random.uniform(-gamma1, gamma1, (n, d))
        A_ = ig.Graph.Erdos_Renyi(n=n, p=poss1)
        A_.es['weight'] = np.random.normal(0, 1, len(A_.es))
        A = np.array(A_.get_adjacency(attribute='weight').data)
        rhoA = max(np.linalg.eig(A)[0])
        A = (rho1 / abs(rhoA)) * A

        WinV1 = np.dot(Win, V1)
        for h in range(len(t_ini) - 1):
            R1[:, h + 1] = (1 - alpha1) * R1[:, h] + \
                           alpha1 * np.tanh(np.dot(A, R1[:, h]) + WinV1[:, h])
        R[:, 0] = R1[:, -1]

        WinV = np.dot(Win, V)
        for i in range(len(t_train) - 1):
            R[:, i + 1] = (1 - alpha1) * R[:, i] + \
                          alpha1 * np.tanh(np.dot(A, R[:, i]) + WinV[:, i])
        r1 += R

    return r1                 # R_tra_RC



CMAP = "seismic"
HEATMAP_BASIS = "diff"
DETECT_BASIS  = "diff"
K = 5.0  #If the L2 norm of column 𝑖 in diff(R_np) exceeds the threshold, a state change is detected at time 𝑖.
i0, i1 = 1000, 2500 # time span: (1000, 2500)


def prep_matrix_for_basis(M, i0, i1, basis):
    seg = M[:, i0:i1]
    if basis == "raw":
        return seg, (i0, i1)
    elif basis == "diff":
        D = np.diff(seg, axis=1)  # t_train[i0+1:i1]
        return D, (i0 + 1, i1)
    else:
        raise ValueError("basis must be 'raw' or 'diff'")


def column_norms(Mseg):
    """L2 norm"""
    return np.sqrt(np.sum(Mseg * Mseg, axis=0))


def exceed_positions(M, t, i0, i1, basis, k):
    Muse, (j0, j1) = prep_matrix_for_basis(M, i0, i1, basis)
    norms = column_norms(Muse)
    idxs = np.where(norms > k)[0]
    xarr = t[j0:j1]
    return xarr[idxs], norms


def imshow_data(M, t, i0, i1, basis, ax, cmap):
    H, (j0, j1) = prep_matrix_for_basis(M, i0, i1, basis)
    im = ax.imshow(
        H,
        aspect="auto",
        extent=[t[j0], t[j1], 0, H.shape[0]],
        cmap=cmap,
        origin="lower",
    )
    return im


def plot_single_panel(R_tra_RC, R_tra, R_np, idx):

    fig = plt.figure(figsize=(8, 6))
    gs = GridSpec(3, 1, hspace=0.05)

    ax1 = fig.add_subplot(gs[0, 0])
    im1 = imshow_data(R_tra_RC, t_train, i0, i1, HEATMAP_BASIS, ax1, CMAP)
    ax1.set_ylabel(r'TRRC, $\Delta r_{\mathrm{train}}^{i}$', labelpad=2)
    ax1.tick_params(axis='x', which='both', labelbottom=False)
    plt.colorbar(im1, ax=ax1, fraction=0.046, pad=0.01)

    ax2 = fig.add_subplot(gs[1, 0], sharex=ax1)
    im2 = imshow_data(R_tra, t_train, i0, i1, HEATMAP_BASIS, ax2, CMAP)
    ax2.set_ylabel(r'DBRC, $\Delta r_{\mathrm{train}}^{i}$', labelpad=2)
    ax2.tick_params(axis='x', which='both', labelbottom=False)
    plt.colorbar(im2, ax=ax2, fraction=0.046, pad=0.01)

    ax3 = fig.add_subplot(gs[2, 0], sharex=ax1)
    ax3.plot(t_train[i0:i1], x_train[i0:i1], color='#a1d99b', lw=1.0, alpha=0.9)
    ax3.plot(t_train[i0:i1], y_train[i0:i1], color='#fdae6b', lw=1.0, alpha=0.9)
    ax3.plot(t_train[i0:i1], z_train[i0:i1], color='#9ecae1', lw=1.0, alpha=0.9)
    ax3.set_ylabel(r'DBRC, $\Delta r_{\mathrm{ref}}^{j}$', labelpad=2)
    ax3.set_xlabel("time")
    xs_np, _ = exceed_positions(R_np, t_train, i0, i1, DETECT_BASIS, K)
    for xv in xs_np:
        ax3.axvline(xv, color='k', ls='--', lw=1.0, alpha=0.9)

    fig.suptitle(f"Lorenz, fixed hyper", fontsize=10)
    plt.tight_layout()
    plt.savefig()
    plt.close()
    #plt.show()



if __name__ == "__main__":

    print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))

    for i in range(100):
        R_tra, R_np, Index = Lorenz_Pred(i)
        Index = 500 + Index.astype(int)

        np.save(f"{BASE_SAVE}/R_tra_{i}.npy", R_tra)
        np.save(f"{BASE_SAVE}/R_np_{i}.npy", R_np)
        np.save(f"{BASE_SAVE}/Index_{i}.npy", Index)

        R_tra_rc = Lorenz_Pred_RC(i)
        np.save(f"{BASE_SAVE}/R_tra_RC_{i}.npy", R_tra_rc)

        plot_single_panel(R_tra_RC=R_tra_rc, R_tra=R_tra, R_np=R_np, idx=i)

        print(i, time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
