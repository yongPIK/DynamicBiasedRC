import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed


path_ori1 = "C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx"
data1 = pd.read_excel(path_ori1)
T = data1["time"].to_numpy()
X1 = data1["x"].tolist()
Y1 = data1["y"].tolist()
Z1 = data1["z"].tolist()

thr = 0.2
DT = 0.01 / 1.014



def compute_lya_rc(args):

    i, length = args

    idx0 = int(length / 0.01)
    x = X1[idx0 + 4000: idx0 + 5014]
    y = Y1[idx0 + 4000: idx0 + 5014]
    z = Z1[idx0 + 4000: idx0 + 5014]
    Ri = np.array([x, y, z])

    path_pre = f"C:/Users/Lenovo/Desktop/RC/Lorenz/Data/pre/times{i}.xlsx"
    data = pd.read_excel(path_pre)
    X = data["x"].tolist()
    Y = data["y"].tolist()
    Z = data["z"].tolist()
    R = np.array([X, Y, Z])

    rmse = np.sqrt(np.mean((Ri - R) ** 2, axis=0))
    nrmse = rmse / (np.std(Ri, axis=0))

    try:
        indexs = np.where(nrmse > thr)
        step_idx = indexs[0][0]
    except Exception:
        step_idx = R.shape[1]

    return step_idx  #steps


def compute_lya_psrc(args):

    i, length = args

    idx0 = int(length / 0.01)
    x = X1[idx0 + 4000: idx0 + 5014]
    y = Y1[idx0 + 4000: idx0 + 5014]
    z = Z1[idx0 + 4000: idx0 + 5014]
    Ri = np.array([x, y, z])

    path_pre = f"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/DifferentWarmUp/pre/times{i}.xlsx"
    data = pd.read_excel(path_pre)
    X = data["x"].tolist()
    Y = data["y"].tolist()
    Z = data["z"].tolist()
    R = np.array([X, Y, Z])

    rmse = np.sqrt(np.mean((Ri - R) ** 2, axis=0))
    nrmse = rmse / (np.std(Ri, axis=0))

    try:
        indexs = np.where(nrmse > thr)
        pre_t = indexs[0][0] * DT
    except Exception:
        pre_t = R.shape[1] * DT

    return pre_t


def Analysis_RC(length=10, start=0, end=5000, max_workers=None):

    if max_workers is None:
        max_workers = max(1, (mp.cpu_count() or 2) - 1)

    args_list = [(i, length) for i in range(start, end)]

    lyatime_steps = []
    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        for step_idx in ex.map(compute_lya_rc, args_list):
            lyatime_steps.append(step_idx)

    lyatime_steps = np.array(lyatime_steps)

    return lyatime_steps * DT  #vpt


def Analysis_PSRC(length=10, start=0, end=5000, max_workers=None):

    if max_workers is None:
        max_workers = max(1, (mp.cpu_count() or 2) - 1)

    args_list = [(i, length) for i in range(start, end)]

    lyatime = []
    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        for pre_t in ex.map(compute_lya_psrc, args_list):
            lyatime.append(pre_t)

    return np.array(lyatime)



def count_times(data, X):
    data2 = data - min(X)
    counts = np.bincount(data2, minlength=(max(X) - min(X) + 1))
    return counts


if __name__ == '__main__':
    mp.set_start_method("spawn", force=True)

    t0 = time.time()
    lya_rc = Analysis_RC().round().astype(int)
    lya_psrc = Analysis_PSRC().round().astype(int)
    print(f"Analysis done in {time.time() - t0:.2f} s")

    np.save(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/DifferentWarmUp/ShortTimeAnalysis/rc.npy", lya_rc)
    np.save(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/DifferentWarmUp/ShortTimeAnalysis/psrc.npy", lya_psrc)


    X = np.arange(min(lya_psrc.min(), lya_rc.min()),
                 max(lya_psrc.max(), lya_rc.max()) + 1)

    lya_psrc_num = count_times(lya_psrc, X)
    lya_rc_num = count_times(lya_rc, X)

    bar_width = 0.4
    x_psrc = X + bar_width / 2
    x_rc = X - bar_width / 2

    plt.bar(x_psrc, lya_psrc_num, width=bar_width, label='PSRC', align='center', color="red")
    plt.bar(x_rc, lya_rc_num, width=bar_width, label='RC', align='center', color="blue")

    plt.xticks(X)
    plt.xlabel("prediction time")
    plt.ylabel("times")
    plt.legend()
    #plt.savefig()
    plt.show()
