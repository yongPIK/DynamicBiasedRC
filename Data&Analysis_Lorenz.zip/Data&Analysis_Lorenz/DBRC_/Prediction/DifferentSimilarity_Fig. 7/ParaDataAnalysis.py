import os
import time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp


path_ori1 = "C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx"
data1 = pd.read_excel(path_ori1)
T = data1["time"].to_numpy()
X1 = data1["x"].to_numpy()
Y1 = data1["y"].to_numpy()
Z1 = data1["z"].to_numpy()

thr = 0.2
length = 10
dt = 0.01 / 1.014


x_psrc = X1[int(length/0.01)+4000:int(length/0.01)+5014]
y_psrc = Y1[int(length/0.01)+4000:int(length/0.01)+5014]
z_psrc = Z1[int(length/0.01)+4000:int(length/0.01)+5014]
Ri_psrc = np.vstack([x_psrc, y_psrc, z_psrc])  # shape: (3, T)
std_Ri_psrc = Ri_psrc.std(axis=0, ddof=0) + 1e-12


def make_Ri_rc(length_rc=50):
    x = X1[length_rc*100:1014 + length_rc*100]
    y = Y1[length_rc*100:1014 + length_rc*100]
    z = Z1[length_rc*100:1014 + length_rc*100]
    Ri = np.vstack([x, y, z])
    return Ri, Ri.std(axis=0, ddof=0) + 1e-12

def _time_from_file(path_xlsx: str, Ri: np.ndarray, std_Ri: np.ndarray, thr: float, dt: float) -> float | None:

    try:
        df = pd.read_excel(path_xlsx, engine="openpyxl")
    except Exception:
        return None

    if not set(["x", "y", "z"]).issubset(df.columns):
        return None

    R = df[["x", "y", "z"]].to_numpy().T  # (3, T')
    m = min(R.shape[1], Ri.shape[1])
    if m == 0:
        return None

    Rm = R[:, :m]
    Rim = Ri[:, :m]
    stdm = std_Ri[:m]

    rmse = np.sqrt(np.mean((Rim - Rm) ** 2, axis=0))
    nrmse = rmse / stdm

    mask = nrmse > thr
    if mask.any():
        idx = int(np.argmax(mask))
        return (idx) * dt
    else:
        return m * dt  #vpt



def psrc_times_for_size(size: str, base_dir: str, Ri: np.ndarray, std_Ri: np.ndarray, thr: float, dt: float):
    times = []
    for i in range(100): #fixed hyper←; if random hyper: range(100,200)
        path_pre = os.path.join(base_dir, f"{size}", "data", f"times{i}.xlsx")
        tval = _time_from_file(path_pre, Ri, std_Ri, thr, dt)
        if tval is not None:
            times.append(tval)
    return size, np.array(times, dtype=float)

def rc_times_once(base_dir_rc: str, Ri: np.ndarray, std_Ri: np.ndarray, thr: float, dt: float):
    times = []
    for i in range(100): #fixed hyper←; if random hyper: range(100,200)
        path_pre = os.path.join(base_dir_rc, "times" + str(i) + ".xlsx")
        tval = _time_from_file(path_pre, Ri, std_Ri, thr, dt)
        if tval is not None:
            times.append(tval)
    return np.array(times, dtype=float)

# ---------------- 主流程 ----------------
if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)

    base_dir_psrc = r"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/Nearest"
    base_dir_rc   = r"C:/Users/Lenovo/Desktop/RC/Lorenz/Data/long"


    sizes = ["randomr"] + [str(i) for i in range(1, 10)]
    labels = ["randomr"] + [str(i) for i in range(1, 10)]


    max_workers = max(1, (os.cpu_count() or 4) // 2)
    means_psrc, stds_psrc = [], []

    print(f"Submitting {len(sizes)} PSRC tasks with max_workers={max_workers} ...")
    futures = {}
    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        for s in sizes:
            fut = ex.submit(psrc_times_for_size, s, base_dir_psrc, Ri_psrc, std_Ri_psrc, thr, dt)
            futures[fut] = s

        for i, fut in enumerate(as_completed(futures), 1):
            s, arr = fut.result()
            if arr.size == 0:
                mu, sd = np.nan, np.nan
            else:
                mu, sd = float(np.mean(arr)), float(np.std(arr)/10.0)
            means_psrc.append((s, mu))
            stds_psrc.append((s, sd))
            print(f"[{i}/{len(sizes)}] size={s}: n={arr.size}, mean={mu:.4f}, std/10={sd:.4f}")


    Ri_rc, std_Ri_rc = make_Ri_rc(length_rc=50)
    arr_rc = rc_times_once(base_dir_rc, Ri_rc, std_Ri_rc, thr, dt)
    mean_rc = float(np.mean(arr_rc)) if arr_rc.size else np.nan
    std_rc  = float(np.std(arr_rc)/10.0) if arr_rc.size else np.nan


    size2mu = dict(means_psrc)
    size2sd = dict(stds_psrc)
    means_psrc_list = [size2mu.get(s, np.nan) for s in sizes]
    stds_psrc_list  = [size2sd.get(s, np.nan) for s in sizes]
    means_rc_list   = [mean_rc for _ in sizes]
    stds_rc_list    = [std_rc  for _ in sizes]

    np.save(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/means_psrc_similarity", means_psrc_list)
    np.save(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/means_rc_similarity", means_rc_list)
    np.save(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/stds_psrc_similarity", stds_psrc_list)
    np.save(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/stds_rc_similarity", stds_rc_list)


    x = np.arange(len(sizes))

    plt.figure(figsize=(9, 5))
    plt.errorbar(x, means_psrc_list, yerr=stds_psrc_list, fmt='o-', capsize=5, label='DBRC', color="red")
    plt.errorbar(x, means_rc_list,   yerr=stds_rc_list,   fmt='o-', capsize=5, label='TRRC', color="blue")
    plt.xlabel("Reference State")
    plt.ylabel("Average Valid Prediction Time")
    plt.title("Prediction Time of Different Reference State")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.xticks(x, labels, rotation=0)
    plt.tight_layout()
    out_fig = os.path.join(os.getcwd(), "fix.png")
    plt.legend()
    #plt.savefig()
    plt.show()

