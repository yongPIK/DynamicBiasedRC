import os
import numpy as np
import pandas as pd
import igraph as ig
import time
from numba import njit
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp


d = 3
n = 200
length = 10

#rho = 1.09
gamma = 0.06
alpha = 0.13
#poss = 0.05
beta = 10**(-7)

data = pd.read_excel("C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx")
T = data["time"].to_numpy()
X = data["x"].tolist()
Y = data["y"].tolist()
Z = data["z"].tolist()

t_ini = T[:int(length / 0.01)]
x_ini = X[:int(length / 0.01)]
y_ini = Y[:int(length / 0.01)]
z_ini = Z[:int(length / 0.01)]
t_train = (T[int(length / 0.01)-1:int(length / 0.01)+4000]) / 1.014
x_train = X[int(length / 0.01)-1:int(length / 0.01)+4000]
y_train = Y[int(length / 0.01)-1:int(length / 0.01)+4000]
z_train = Z[int(length / 0.01)-1:int(length / 0.01)+4000]
t_test = (T[int(length / 0.01)+4000:int(length/0.01)+5014] - T[int(length / 0.01)+4000]) / 1.014
x_test = X[int(length / 0.01)+4000:int(length/0.01)+5014]
y_test = Y[int(length / 0.01)+4000:int(length/0.01)+5014]
z_test = Z[int(length / 0.01)+4000:int(length/0.01)+5014]
V = np.array([x_train, y_train, z_train])
V1 = np.array([x_ini, y_ini, z_ini])

OUT_ROOT = r"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/Nearest"

def ensure_dirs(maxi: int) -> str:
    base = os.path.join(OUT_ROOT, f"{int(maxi)}")
    os.makedirs(os.path.join(base, "data"), exist_ok=True)
    os.makedirs(os.path.join(base, "ppic"), exist_ok=True)
    return base

def generate_A(n, p):
    A_ = ig.Graph.Erdos_Renyi(n=n, p=p)
    A_.es['weight'] = np.random.normal(0, 1, len(A_.es))
    A = np.array(A_.get_adjacency(attribute='weight').data)
    return A

def normalize_A(A, rho):
    rhoA = max(np.linalg.eig(A)[0])
    A_normalized = (rho / abs(rhoA)) * A
    return A_normalized


@njit(cache=True, fastmath=True)
def nn(point, data, maxi):
    m = data.shape[1]
    point = np.ascontiguousarray(point)
    data  = np.ascontiguousarray(data)
    s = np.dot(data.T, point)
    idx = np.argsort(s)[-maxi]
    return data[:, idx]

@njit(cache=True, fastmath=True)
def update(R, A, WinV, alpha=0.13):
    for i in range(R.shape[1] - 1):
        R[:, i + 1] = (1 - alpha) * R[:, i] + alpha * np.tanh(np.dot(A, np.ascontiguousarray(R[:, i])) + WinV[:, i])
    return R

@njit(cache=True, fastmath=True)
def update_nn(R, R1, A, WinV, maxi, alpha=0.13):
    for i in range(R.shape[1] - 1):
        nei = nn(R[:, i], R1, maxi)
        R[:, i + 1] = (1 - alpha) * R[:, i] + alpha * np.tanh(np.dot(A, np.ascontiguousarray(nei)) + WinV[:, i])
    return R

def _warmup_numba():
    n_w, t_ini_w, t_train_w = 8, 5, 7
    Rw  = np.zeros((n_w, t_train_w))
    R1w = np.zeros((n_w, t_ini_w))
    Aw  = np.random.randn(n_w, n_w) * 0.1
    WinVw = np.random.randn(n_w, t_train_w) * 0.1
    point = np.random.randn(n_w)
    maxi  = 2
    _ = nn(point, R1w, maxi)
    _ = update(Rw, Aw, WinVw, 0.13)
    _ = update_nn(Rw, R1w, Aw, WinVw, maxi, 0.13)


def lorenz(k: int, maxi: int):
    base = ensure_dirs(maxi)
    rho = np.round(np.random.uniform(0.01, 0.99), 2)
    poss = np.round(np.random.uniform(0.01, 0.99), 2)
    Pred = np.zeros((d, len(t_test)))
    for _ in range(1):
        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))

        Win = np.random.uniform(-gamma, gamma, (n, d))

        A = generate_A(n, poss)
        A = normalize_A(A, rho)

        WinV1 = np.dot(Win, V1)
        R1 = update(R1, A, WinV1, alpha)[:, 500:]
        R[:, 0] = R1[:, -1]

        WinV = np.dot(Win, V)
        R = update_nn(R, R1, A, WinV, int(maxi), alpha)
        r = R[:, -1]
        Wout = np.dot(np.dot(V, np.transpose(R)),
                      np.linalg.inv(np.dot(R, np.transpose(R)) + beta * np.eye(n)))

        for j in range(len(t_test)):
            Nearest_ind = nn(r, R1, int(maxi))
            r = (1 - alpha) * r + alpha * np.tanh(np.dot(A, Nearest_ind) + np.dot(Win, np.dot(Wout, r)))
            Pred[:, j] += np.dot(Wout, r)

    xline, yline, zline = Pred[0, :], Pred[1, :], Pred[2, :]

    df = pd.DataFrame({"x": xline, "y": yline, "z": zline})
    df.to_excel(os.path.join(base, "data", f"times{k}.xlsx"), sheet_name="sheet1", index=False)

    fig, axs = plt.subplots(3)
    axs[0].plot(t_test, xline); axs[0].plot(t_test, x_test); axs[0].set_title('x')
    axs[1].plot(t_test, yline); axs[1].plot(t_test, y_test); axs[1].set_title('y')
    axs[2].plot(t_test, zline); axs[2].plot(t_test, z_test); axs[2].set_title('z')
    plt.tight_layout()
    plt.savefig(os.path.join(base, "ppic", f"times{k}.jpg"))
    plt.close()

    return k

def run_one_maxi(maxi: int, start: int = 100, end: int = 200):
    _warmup_numba()
    done = []
    for k in range(start, end):
        lorenz(k, maxi)
        done.append(k)
    return maxi, done

if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)

    max_workers = max(1, (os.cpu_count() or 2) - 1)
    maxi_list = list(range(10)) #this controls similarity range

    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        futs = {ex.submit(run_one_maxi, maxi, 100, 200): maxi for maxi in maxi_list}
        submitted = len(futs)
        print(f"submitted {submitted} tasks: maxi={min(maxi_list)}..{max(maxi_list)}")
        for fut in as_completed(futs):
            maxi, ks = fut.result()
            print(ks)
            print(f"maxi={maxi} finished k={min(ks)}..{max(ks)} at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}")
