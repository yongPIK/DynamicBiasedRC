import numpy as np
import pandas as pd
import igraph as ig
import time
from numba import njit

d = 3
n = 200

gamma = 0.06
alpha = 0.13
beta = 10**(-7)

length = 10
thr = 0.2

data = pd.read_excel("C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx")
T = data["time"].to_numpy()
X = data["x"].tolist()
Y = data["y"].tolist()
Z = data["z"].tolist()

t_ini = T[:int(length / 0.01)]
x_ini = X[:int(length / 0.01)]
y_ini = Y[:int(length / 0.01)]
z_ini = Z[:int(length / 0.01)]
t_train = (T[int(length / 0.01)-1:int(length / 0.01)+4000])/1.014
x_train = X[int(length / 0.01)-1:int(length / 0.01)+4000]
y_train = Y[int(length / 0.01)-1:int(length / 0.01)+4000]
z_train = Z[int(length / 0.01)-1:int(length / 0.01)+4000]
t_test = (T[int(length / 0.01)+4000:int(length/0.01)+5014]-T[int(length / 0.01)+5000])/1.014
x_test = X[int(length / 0.01)+4000:int(length/0.01)+5014]
y_test = Y[int(length / 0.01)+4000:int(length/0.01)+5014]
z_test = Z[int(length / 0.01)+4000:int(length/0.01)+5014]
V = np.array([x_train, y_train, z_train])
V1 = np.array([x_ini, y_ini, z_ini])

rho = np.linspace(0,3,150) #delta_rho = 0.02
poss = np.linspace(0.001, 0.999, 50)  #d_poss = 0.02

def generate_A(poss, rho, n=n):
    A_ = ig.Graph.Erdos_Renyi(n=n, p=poss)
    A_.es['weight'] = np.random.normal(0, 1, len(A_.es))
    A = np.array(A_.get_adjacency(attribute='weight').data)
    rhoA = max(np.linalg.eig(A)[0])
    A = (rho / abs(rhoA)) * A
    return A

@njit
def nn(point, data):
    point = np.ascontiguousarray(point)
    data = np.ascontiguousarray(data) 
    s = np.dot(data.T,point)
    index = np.argmax(s)
    return data[:, index]
    
@njit
def update(R, A, WinV, alpha=alpha):
    for i in range(R.shape[1]-1):
        R[:, i+1] = (1 - alpha) * R[:, i] + alpha * np.tanh(np.dot(A,np.ascontiguousarray(R[:, i])) + WinV[:, i])
    return R

@njit
def update_nn(R, R1, A, WinV, alpha=alpha):
    for j in range(R.shape[1]-1):
        nei = nn(R[:, j],R1)
        R[:, j+1] = (1 - alpha) * R[:, j] + alpha * np.tanh(np.dot(A,np.ascontiguousarray(nei)) + WinV[:, j])
    return R

def lorenz(p, rho, n=n):
    Pred = np.zeros((d, len(t_test)))
    for times in range(500):
        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))
        
        Win = np.random.uniform(-gamma, gamma, (n, d))
        
        A = generate_A(p,rho)

        WinV1 = np.dot(Win,V1)
        R1 = update(R1, A, WinV1, alpha)[:, 500:]
        R[:, 0] = R1[:, -1]

        WinV = np.dot(Win,V)
        R = update_nn(R, R1, A, WinV, alpha)
        r = R[:, -1]
        Wout = np.dot(np.dot(V, np.transpose(R)),
                      np.linalg.inv(np.dot(R, np.transpose(R)) + beta * np.eye(n)))

        for h in range(len(t_test)):
            Nearest_ind = nn(r, R1)
            r = (1 - alpha) * r + alpha * np.tanh(np.dot(A,Nearest_ind) + \
                                                np.dot(Win,np.dot(Wout,r)))

            Pred[:, h] += np.dot(Wout,r)
    
                          
    Pred = Pred / 500
    
    xline = Pred[0, :]
    yline = Pred[1, :]
    zline = Pred[2, :]

    R11 = np.array([x_test, y_test, z_test])
    R22 = np.array([xline, yline, zline])
    rmse = np.sqrt(np.mean((R11 - R22) ** 2, axis=0))
    nrmse = rmse / (np.std(R11, axis=0))

    indexs = np.where(nrmse > thr)  # nrmse大于阈值的所有下标

    pre_t = indexs[0][0] * 0.01 / 1.104

    return pre_t

print(f"rho={rho}")
R_phase1 = np.zeros((len(poss),len(rho)))
print(R_phase1.shape)
j=-1
for r in rho:
    j += 1
    i=-1
    for p in poss:
        print(r,p)
        i += 1
        print(i,j)
        R_phase1[i,j] = lorenz(p, r)
        print(R_phase1[i,j],time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())), flush=True)

np.save("C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/DifferentWarmUp/Robustness/Phase.npy", R_phase1)



