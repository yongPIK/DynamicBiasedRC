import numpy as np
import pandas as pd
import igraph as ig
import time
from numba import njit
import matplotlib.pyplot as plt

d = 3
n = 200
length = 10

data = pd.read_excel(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx")
T = data["time"].to_numpy()
X = data["x"].to_numpy()
Y = data["y"].to_numpy()
Z = data["z"].to_numpy()

gamma = 0.06
alpha = 0.13
beta = 10**(-7)

data = pd.read_excel("C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx")
T = data["time"].to_numpy()
X = data["x"].tolist()
Y = data["y"].tolist()
Z = data["z"].tolist()

t_ini = T[:int(length / 0.01)]
x_ini = X[:int(length / 0.01)]
y_ini = Y[:int(length / 0.01)]
z_ini = Z[:int(length / 0.01)]
t_train = (T[int(length / 0.01)-1:int(length / 0.01)+4000])/1.014
x_train = X[int(length / 0.01)-1:int(length / 0.01)+4000]
y_train = Y[int(length / 0.01)-1:int(length / 0.01)+4000]
z_train = Z[int(length / 0.01)-1:int(length / 0.01)+4000]
t_test = (T[int(length / 0.01)+4000:int(length/0.01)+5014]-T[int(length / 0.01)+4000])/1.014
x_test = X[int(length / 0.01)+4000:int(length/0.01)+5014]
y_test = Y[int(length / 0.01)+4000:int(length/0.01)+5014]
z_test = Z[int(length / 0.01)+4000:int(length/0.01)+5014]
V = np.array([x_train, y_train, z_train])
V1 = np.array([x_ini, y_ini, z_ini])


def generate_A(n, p, rho):
    A_ = ig.Graph.Erdos_Renyi(n=n, p=p)
    A_.es['weight'] = np.random.normal(0, 1, len(A_.es))
    A = np.array(A_.get_adjacency(attribute='weight').data)
    rhoA = max(np.linalg.eig(A)[0])
    A_normalized = (rho / abs(rhoA)) * A
    return A_normalized

@njit
def nn(point, data):
    point = np.ascontiguousarray(point)
    data = np.ascontiguousarray(data)
    s = np.dot(data.T, point)
    index = np.argmax(s)
    return data[:, index]

@njit
def update(R, A, WinV, alpha=alpha):
    for i in range(R.shape[1] - 1):
        R[:, i + 1] = (1 - alpha) * R[:, i] + alpha * np.tanh(np.dot(A, R[:, i]) + WinV[:, i])
    return R

@njit
def update_nn(R, R1, A, WinV, alpha=alpha):
    for i in range(R.shape[1]-1):
        nei = nn(R[:, i], R1)
        R[:, i+1] = (1 - alpha) * R[:, i] + alpha * np.tanh(np.dot(A, R[:, i]) + WinV[:, i] + nei)
    return R

def lorenz(k):

    rho = np.round(np.random.uniform(0.01, 0.99), 2)
    poss = np.round(np.random.uniform(0.01, 0.99), 2)
    Pred = np.zeros((d, len(t_test)))

    for t in range(1):

        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))

        Win = np.random.uniform(-gamma, gamma, (n, d))

        A = generate_A(n, poss, rho)

        WinV1 = np.dot(Win, V1)
        R1 = update(R1, A, WinV1, alpha)[:, 500:]
        R[:, 0] = R1[:, -1]

        WinV = np.dot(Win, V)
        R = update_nn(R, R1, A, WinV, alpha)
        r = R[:, -1]
        Wout = np.dot(np.dot(V, np.transpose(R)),
                      np.linalg.inv(np.dot(R, np.transpose(R)) + beta * np.eye(n)))

        for j in range(len(t_test)):
            Nearest_ind = nn(r, R1)
            r = (1 - alpha) * r + alpha * np.tanh(np.dot(A, r) + \
                                                  np.dot(Win, np.dot(Wout, r)) + Nearest_ind)

            Pred[:, j] += np.dot(Wout, r)

    Pred = Pred / 1

    xline = Pred[0, :]
    yline = Pred[1, :]
    zline = Pred[2, :]


    col1 = 'x'
    col2 = "y"
    col3 = "z"
    data = pd.DataFrame({col1: xline, col2: yline, col3: zline})
    data.to_excel("C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/DifferentBias/ref/data/times{}.xlsx".format(k), sheet_name="sheet1", index=False)
    fig, axs = plt.subplots(3)
    axs[0].plot(t_test, xline)
    axs[0].plot(t_test, x_test)
    axs[0].set_title('x')
    axs[1].plot(t_test, yline)
    axs[1].plot(t_test, y_test)
    axs[1].set_title('y')
    axs[2].plot(t_test, zline)
    axs[2].plot(t_test, z_test)
    axs[2].set_title('z')
    plt.tight_layout()
    plt.savefig("C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/DifferentBias/ref/ppic/times{}.jpg".format(k))
    plt.close()

    return

print("T={}".format(length-5))
for k in range(100,200):
    lorenz(k)
    print(k,time.strftime( '%Y-%m-%d %H:%M:%S' ,time.localtime(time.time())))

