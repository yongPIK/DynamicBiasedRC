import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt

path_ori1 = "C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx"
data1 = pd.read_excel(path_ori1)
T = data1["time"].to_numpy()
X1 = data1["x"].tolist()
Y1 = data1["y"].tolist()
Z1 = data1["z"].tolist()
thr = 0.2

def Analysis_PSRC(form, a):
    length = 10
    lyatime = []
    x = X1[int(length / 0.01)+4000 : int(length/0.01)+5014]
    y = Y1[int(length / 0.01)+4000 : int(length/0.01)+5014]
    z = Z1[int(length / 0.01)+4000 : int(length/0.01)+5014]
    Ri = np.array([x,y,z])
    for i in range(a, a+100): #fixed hyper: 0-100; random hyper: 100-200
        path_pre = "C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/DifferentBias/{}/data/times{}.xlsx".format(form, i)
        data = pd.read_excel(path_pre)
        X = data["x"].tolist()
        Y = data["y"].tolist()
        Z = data["z"].tolist()
        R = np.array([X, Y, Z])
        rmse = np.sqrt(np.mean((Ri - R) ** 2, axis=0))
        nrmse = rmse / (np.std(Ri, axis=0))
        try:
            indexs = np.where(nrmse > thr)
            lyatime.append(indexs[0][0]* 0.01 / 1.014)
        except Exception as e:
            lyatime.append(R.shape[1]* 0.01 / 1.014)
    return np.array(lyatime)


def Analysis_RC():
    length = 50
    lyatime = []
    x = X1[int(length/0.01) : int(length/0.01)+1014]
    y = Y1[int(length/0.01) : int(length/0.01)+1014]
    z = Z1[int(length/0.01) : int(length/0.01)+1014]
    Ri = np.array([x,y,z])
    for i in range(100): # 0-5000: fix hyper prediction; 5000-10000:random hyper prediction. Choose 100 results.
        path_pre = "C:/Users/Lenovo/Desktop/RC/Lorenz/Data/pre/times{}.xlsx".format(i)
        data = pd.read_excel(path_pre)
        X = data["x"].tolist()
        Y = data["y"].tolist()
        Z = data["z"].tolist()
        R = np.array([X, Y, Z])
        rmse = np.sqrt(np.mean((Ri - R) ** 2, axis=0))
        nrmse = rmse / (np.std(Ri, axis=0))
        try:
            indexs = np.where(nrmse > thr)
            lyatime.append(indexs[0][0])
        except Exception as e:
            lyatime.append(R.shape[1])
    return np.array(lyatime) * 0.01 / 1.014

def count_times(data, X):
    data2 = data - min(X)
    counts = np.bincount(data2, minlength=(max(X) - min(X) + 1))
    return counts

if __name__ == '__main__':

    X = [0, 0, 0, 0]
    x = ["Aref", "ref", "Aref-train", "ref-train"]

    means_psrc = []
    stds_psrc = []
    means_rc = []
    stds_rc = []

    results_rc = Analysis_RC()
    for i in range(4):
        results = Analysis_PSRC(x[i], X[i])
        means_psrc.append(np.mean(results))
        stds_psrc.append(np.std(results) / 10)
        means_rc.append(np.mean(results_rc))
        stds_rc.append(np.std(results_rc) / 10)

    bar_width = 0.35
    X_loc = np.array([0, 1, 2, 3])

    plt.figure(figsize=(8, 5))
    plt.errorbar(X_loc + bar_width / 2, means_rc, yerr=stds_rc, fmt='o-', capsize=5)
    plt.errorbar(X_loc - bar_width / 2, means_psrc, yerr=stds_psrc, fmt='o-', capsize=5)
    plt.bar(X_loc - bar_width / 2, means_psrc,
            yerr=stds_psrc, capsize=5,
            width=bar_width, label="DBRC", color="red")
    plt.bar(X_loc + bar_width / 2, means_rc,
            yerr=stds_rc, capsize=5,
            width=bar_width, label="TRRC", color="blue")
    plt.xlabel("bias construction")
    plt.ylabel("Average Valid Prediction Time")
    plt.title("Prediction Time of Different bias")
    plt.xticks(X_loc, x)
    plt.tight_layout()
    plt.legend()
    # plt.savefig()
    plt.show()

