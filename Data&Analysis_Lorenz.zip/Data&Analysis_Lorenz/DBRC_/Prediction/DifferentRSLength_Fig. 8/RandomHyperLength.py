import os
import time
import numpy as np
import pandas as pd
import igraph as ig
from numba import njit
import matplotlib.pyplot as plt
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed


d = 3
n = 200

gamma = 0.06
alpha = 0.13
beta = 10 ** (-7)


data = pd.read_excel(
    r"C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx",
    engine="openpyxl"
)
T = data["time"].to_numpy()
X = data["x"].to_numpy()
Y = data["y"].to_numpy()
Z = data["z"].to_numpy()



def make_segments(length: int):

    idx0 = int((length * 1.014) / 0.01 + 500)

    t_ini = T[:idx0]
    x_ini = X[:idx0]
    y_ini = Y[:idx0]
    z_ini = Z[:idx0]

    t_train = T[idx0 - 1: idx0 + 4000] / 1.014
    x_train = X[idx0 - 1: idx0 + 4000]
    y_train = Y[idx0 - 1: idx0 + 4000]
    z_train = Z[idx0 - 1: idx0 + 4000]

    t_test = (T[idx0 + 4000: idx0 + 5014] - T[idx0 + 4000]) / 1.014
    x_test = X[idx0 + 4000: idx0 + 5014]
    y_test = Y[idx0 + 4000: idx0 + 5014]
    z_test = Z[idx0 + 4000: idx0 + 5014]

    V = np.array([x_train, y_train, z_train])
    V1 = np.array([x_ini, y_ini, z_ini])

    return (t_ini, x_ini, y_ini, z_ini,
            t_train, x_train, y_train, z_train,
            t_test, x_test, y_test, z_test,
            V, V1)



def generate_A(n, p):
    A_ = ig.Graph.Erdos_Renyi(n=n, p=p)
    A_.es["weight"] = np.random.normal(0.0, 1.0, len(A_.es))
    A = np.array(A_.get_adjacency(attribute="weight").data, dtype=np.float64)
    return A


def normalize_A(A, rho):
    eigvals = np.linalg.eigvals(A)
    rhoA = np.max(np.abs(eigvals))
    return (rho / rhoA) * A



@njit
def nn(point, data):
    point = np.ascontiguousarray(point)
    data = np.ascontiguousarray(data)
    s = np.dot(data.T, point)
    idx = np.argmax(s)
    return data[:, idx]


@njit
def update(R, A, WinV, alpha_val):
    for i in range(R.shape[1] - 1):
        R[:, i + 1] = (1.0 - alpha_val) * R[:, i] + alpha_val * np.tanh(
            np.dot(A, np.ascontiguousarray(R[:, i])) + WinV[:, i]
        )
    return R


@njit
def update_nn(R, R1, A, WinV, alpha_val):
    for i in range(R.shape[1] - 1):
        nei = nn(R[:, i], R1)
        R[:, i + 1] = (1.0 - alpha_val) * R[:, i] + alpha_val * np.tanh(
            np.dot(A, np.ascontiguousarray(nei)) + WinV[:, i]
        )
    return R


def ensure_dirs(length: int):
    base = rf"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/DifferentWarmUp/{length}"
    data_dir = os.path.join(base, "data")
    ppic_dir = os.path.join(base, "ppic")
    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(ppic_dir, exist_ok=True)
    return base, data_dir, ppic_dir



def lorenz_one(length: int, k: int):
    (t_ini, x_ini, y_ini, z_ini,
     t_train, x_train, y_train, z_train,
     t_test, x_test, y_test, z_test,
     V, V1) = make_segments(length)

    Pred = np.zeros((d, len(t_test)))
    rho = np.round(np.random.uniform(0.01, 0.99), 2)
    poss = np.round(np.random.uniform(0.01, 0.99), 2)

    for _ in range(1):
        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))

        Win = np.random.uniform(-gamma, gamma, (n, d))

        A = generate_A(n, poss)
        A = normalize_A(A, rho)

        WinV1 = np.dot(Win, V1)
        R1 = update(R1, A, WinV1, alpha)[:, 500:]
        R[:, 0] = R1[:, -1]

        WinV = np.dot(Win, V)
        R = update_nn(R, R1, A, WinV, alpha)
        r = R[:, -1]

        Wout = np.dot(np.dot(V, R.T),
                      np.linalg.inv(np.dot(R, R.T) + beta * np.eye(n)))

        for j in range(len(t_test)):
            Nearest_ind = nn(r, R1)
            r = (1.0 - alpha) * r + alpha * np.tanh(
                np.dot(A, Nearest_ind) + np.dot(Win, np.dot(Wout, r))
            )
            Pred[:, j] += np.dot(Wout, r)

    Pred = Pred / 1

    xline = Pred[0, :]
    yline = Pred[1, :]
    zline = Pred[2, :]

    base, data_dir, ppic_dir = ensure_dirs(length)

    df = pd.DataFrame({"x": xline, "y": yline, "z": zline})
    df.to_excel(os.path.join(data_dir, f"times{k}.xlsx"),
                sheet_name="sheet1", index=False)

    fig, axs = plt.subplots(3, 1, figsize=(6, 8))
    axs[0].plot(t_test, xline)
    axs[0].plot(t_test, x_test)
    axs[0].set_title("x")

    axs[1].plot(t_test, yline)
    axs[1].plot(t_test, y_test)
    axs[1].set_title("y")

    axs[2].plot(t_test, zline)
    axs[2].plot(t_test, z_test)
    axs[2].set_title("z")

    plt.tight_layout()
    plt.savefig(os.path.join(ppic_dir, f"times{k}.jpg"))
    plt.close(fig)

    return length, k


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)

    lengths = list(range(10))       # 1, 2, ..., 10
    ks = list(range(100, 200))         # k=100...199

    print("Will compute:")
    for L in lengths:
        print(f"  length={L}, save to folder {L-5}")

    max_workers = max(1, (os.cpu_count() or 2) - 1)
    print(f"Using {max_workers} workers")

    start_all = time.time()

    tasks = [(L, k) for L in lengths for k in ks]

    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        fut2task = {
            ex.submit(lorenz_one, L, k): (L, k)
            for (L, k) in tasks
        }

        for fut in as_completed(fut2task):
            L, k = fut2task[fut]
            try:
                _, _ = fut.result()
                status = "OK"
            except Exception as e:
                status = f"ERROR: {e}"

            now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            print(f"[{now}] length={L}, k={k}, status={status}", flush=True)

    print(f"All done")
