import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.patches import ConnectionPatch

path_ori1 = "C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx"
data1 = pd.read_excel(path_ori1)
T = data1["time"].to_numpy()
X1 = data1["x"].tolist()
Y1 = data1["y"].tolist()
Z1 = data1["z"].tolist()

thr = 0.2
length = 10

def Analysis_PSRC_all(length, a):
    lyatimes = []
    for i in range(a, a+100):  #fixed hyper: a=0; random hyper: a=100
        path_pre = f"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/DifferentWarmUp/{length}/times{i}.xlsx"
        data = pd.read_excel(path_pre)
        X = data["x"].tolist()
        Y = data["y"].tolist()
        Z = data["z"].tolist()
        R = np.array([X, Y, Z])
        Xi = X1[int(length / 0.01) + 4000 : int(length / 0.01) + 5014]
        Yi = Y1[int(length / 0.01) + 4000 : int(length / 0.01) + 5014]
        Zi = Z1[int(length / 0.01) + 4000 : int(length / 0.01) + 5014]
        Ri = np.array([Xi, Yi, Zi])
        rmse = np.sqrt(np.mean((Ri - R) ** 2, axis=0))
        nrmse = rmse / (np.std(Ri, axis=0))
        try:
            indexs = np.where(nrmse > thr)
            time = indexs[0][0] * 0.01 / 1.014
        except:
            time = R.shape[1] * 0.01 / 1.014
        lyatimes.append(time)
    return np.array(lyatimes)

def Analysis_RC_all(length, a):
    lyatimes = []
    idx0 = int((length - 5) / 0.01)
    x = X1[idx0 + 4500: idx0 + 5514]
    y = Y1[idx0 + 4500: idx0 + 5514]
    z = Z1[idx0 + 4500: idx0 + 5514]
    Ri = np.array([x, y, z])
    for i in range(100):  #fixed hyper: 0-5000; random hyper:5000-10000.
        path_pre = f"C:/Users/Lenovo/Desktop/RC/Lorenz/Data/pre/times{i}.xlsx"
        data = pd.read_excel(path_pre)
        X = data["x"].tolist()
        Y = data["y"].tolist()
        Z = data["z"].tolist()
        R = np.array([X, Y, Z])
        rmse = np.sqrt(np.mean((Ri - R) ** 2, axis=0))
        nrmse = rmse / (np.std(Ri, axis=0))
        try:
            indexs = np.where(nrmse > thr)
            time = indexs[0][0] * 0.01 / 1.014
        except:
            time = R.shape[1] * 0.01 / 1.014
        lyatimes.append(time)
    return np.array(lyatimes)


X = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
A = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] #fixed hyper; random hyper: A=[100, 100, ..., 100]

means = []
stds = []
means_rc = []
stds_rc = []

results1 = Analysis_RC_all()
for i in range(10):
    results = Analysis_PSRC_all(X[i],A[i])
    means.append(np.mean(results))
    stds.append(np.std(results)/10)
    means_rc.append(np.mean(results1))
    stds_rc.append(np.std(results1)/10)

np.save(r"C:\Users\Lenovo\Desktop\PastState\Lorenz\DifferentLength\means_psrc", means)
np.save(r"C:\Users\Lenovo\Desktop\PastState\Lorenz\DifferentLength\means_rc", means_rc)
np.save(r"C:\Users\Lenovo\Desktop\PastState\Lorenz\DifferentLength\stds_psrc", stds)
np.save(r"C:\Users\Lenovo\Desktop\PastState\Lorenz\DifferentLength\stds_rc", stds_rc)

plt.figure(figsize=(8, 5))
plt.errorbar(X, means, yerr=stds, fmt='o-', capsize=4, label="DBRC", color="red")
plt.scatter(X, means, color='black', s=20)
plt.errorbar(X, means_rc, yerr=stds_rc, fmt='o-', capsize=4, label="TRRC", color="blue")
plt.scatter(X, means_rc, color='black', s=20)
plt.xlabel("Reference State Length")
plt.ylabel("Average Prediction Time")
plt.xticks(X)
plt.xlim(min(X) - 1, max(X) + 1)
plt.legend()
plt.tight_layout()
#plt.savefig()
plt.show()