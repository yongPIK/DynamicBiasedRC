import os
import time
import numpy as np
import pandas as pd
import igraph as ig
from numba import njit
import matplotlib.pyplot as plt
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed


d = 3
n = 200
length = 10

rho = 1.09
gamma = 0.06
alpha = 0.13
poss = 0.05
beta = 10 ** (-7)


data = pd.read_excel(
    r"C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx",
    engine="openpyxl"
)
T = data["time"].to_numpy()
X = data["x"].to_numpy()
Y = data["y"].to_numpy()
Z = data["z"].to_numpy()


idx0 = int(length / 0.01)

t_ini = T[:idx0]
x_ini = X[:idx0]
y_ini = Y[:idx0]
z_ini = Z[:idx0]

t_train = T[idx0 - 1: idx0 + 4000] / 1.014
x_train = X[idx0 - 1: idx0 + 4000]
y_train = Y[idx0 - 1: idx0 + 4000]
z_train = Z[idx0 - 1: idx0 + 4000]

t_test = (T[idx0 + 4000: idx0 + 14140] - T[idx0 + 4000]) / 1.014
x_test = X[idx0 + 4000: idx0 + 14140]
y_test = Y[idx0 + 4000: idx0 + 14140]
z_test = Z[idx0 + 4000: idx0 + 14140]

V = np.array([x_train, y_train, z_train])
V1 = np.array([x_ini, y_ini, z_ini])


BASE_DIR = rf"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/DifferentWarmUp/long"
DATA_DIR = os.path.join(BASE_DIR, "data")
PPIC_DIR = os.path.join(BASE_DIR, "ppic")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PPIC_DIR, exist_ok=True)



def generate_A(n, p):
    g = ig.Graph.Erdos_Renyi(n=n, p=p)
    g.es["weight"] = np.random.normal(0.0, 1.0, len(g.es))
    A = np.array(g.get_adjacency(attribute="weight").data, dtype=np.float64)
    return A


def normalize_A(A, rho):
    eigvals = np.linalg.eigvals(A)
    rhoA = np.max(np.abs(eigvals))
    return (rho / rhoA) * A


@njit
def nn(point, data):
    point = np.ascontiguousarray(point)
    data = np.ascontiguousarray(data)
    s = np.dot(data.T, point)
    index = np.argmax(s)
    return data[:, index]


@njit
def update(R, A, WinV, alpha_val):
    for i in range(R.shape[1] - 1):
        R[:, i + 1] = (1.0 - alpha_val) * R[:, i] + alpha_val * np.tanh(
            np.dot(A, np.ascontiguousarray(R[:, i])) + WinV[:, i]
        )
    return R


@njit
def update_nn(R, R1, A, WinV, alpha_val):
    for i in range(R.shape[1] - 1):
        nei = nn(R[:, i], R1)
        R[:, i + 1] = (1.0 - alpha_val) * R[:, i] + alpha_val * np.tanh(
            np.dot(A, R[:, i]) + WinV[:, i] + np.dot(A, (nei - R[:, i]))
        )
    return R



def lorenz(k):
    
    Pred = np.zeros((d, len(t_test)))

    for _ in range(1):
        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))

        Win = np.random.uniform(-gamma, gamma, (n, d))

        A = generate_A(n, poss)
        A = normalize_A(A, rho)

        #warm up
        WinV1 = np.dot(Win, V1)
        R1 = update(R1, A, WinV1, alpha)[:, 500:]
        R[:, 0] = R1[:, -1]

        #train
        WinV = np.dot(Win, V)
        R = update_nn(R, R1, A, WinV, alpha)
        r = R[:, -1]
        Wout = V @ R.T @ np.linalg.inv(R @ R.T + beta * np.eye(n))

        #prediction
        for j in range(len(t_test)):
            nei = nn(r, R1)
            r = (1 - alpha) * r + alpha * np.tanh(
                np.dot(A, nei) + np.dot(Win, np.dot(Wout, r))
            )
            Pred[:, j] += np.dot(Wout, r)

    Pred = Pred / 1

    xline = Pred[0, :]
    yline = Pred[1, :]
    zline = Pred[2, :]

    df_out = pd.DataFrame({"x": xline, "y": yline, "z": zline})
    out_path = os.path.join(DATA_DIR, f"times{k}.xlsx")
    df_out.to_excel(out_path, sheet_name="sheet1", index=False)

    fig, axs = plt.subplots(3, 1, figsize=(6, 8))
    axs[0].plot(t_test, xline, label="pred")
    axs[0].plot(t_test, x_test, label="true")
    axs[0].set_title("x")

    axs[1].plot(t_test, yline, label="pred")
    axs[1].plot(t_test, y_test, label="true")
    axs[1].set_title("y")

    axs[2].plot(t_test, zline, label="pred")
    axs[2].plot(t_test, z_test, label="true")
    axs[2].set_title("z")

    for ax in axs:
        ax.legend()

    plt.tight_layout()
    ppic_path = os.path.join(PPIC_DIR, f"times{k}.jpg")
    plt.savefig(ppic_path)
    plt.close(fig)

    return k


if __name__ == "__main__":
    print(f"Lorenz system, fixed hyper 1000 times")

    max_workers = max(1, mp.cpu_count() - 1)
    print(f"Using {max_workers} workers")

    Ks = range(1000)

    start_all = time.time()
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(lorenz, k): k for k in Ks}

        for future in as_completed(futures):
            k_done = futures[future]
            try:
                _ = future.result()
                status = "OK"
            except Exception as e:
                status = f"ERROR: {e}"

            now = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
            print(f"k = {k_done:4d}, status = {status}, time = {now}")

    print(f"All done")
