import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor, as_completed
from scipy.spatial import cKDTree
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score


def corr_dim_3d(data_3xN,
                r_min=None, r_max=None, n_r=50,
                theiler=16,
                trim_frac=0.2,
                auto_window=False,
                window_min=6,
                return_debug=False,
                random_state=0):
    rng = np.random.default_rng(random_state)
    X = np.asarray(data_3xN, dtype=float)
    assert X.ndim == 2 and X.shape[0] == 3, "shape: (3, N)"
    X = X.T  # -> (N, 3)
    N = X.shape[0]
    if N < 50:
        raise ValueError("more data points please")


    idx = rng.choice(N, size=min(N, 4000), replace=False)
    Xs = X[idx]
    tree_s = cKDTree(Xs)
    d_knn, _ = tree_s.query(Xs, k=min(16, len(Xs)))
    d_knn = d_knn[:, 1:].reshape(-1)
    if r_min is None:
        r_min = np.quantile(d_knn, 0.10)
    if r_max is None:
        r_max = np.quantile(d_knn, 0.90)
    if not (r_min > 0 and r_max > r_min):
        raise ValueError("set r_min/r_max manually")

    r_vals = np.geomspace(r_min, r_max, n_r)
    tree = cKDTree(X)

    # if no Theiler : count_neighbors
    if theiler <= 0:
        pair_counts = np.array([tree.count_neighbors(tree, r, cumulative=True)
                                for r in r_vals], dtype=float)
    else:
        S = tree.sparse_distance_matrix(tree, max_distance=r_vals[-1])  #COO
        rows, cols, dists = S.row, S.col, S.data
        mask_upper = rows < cols
        rows = rows[mask_upper]; cols = cols[mask_upper]; dists = dists[mask_upper]
        mask_t = np.abs(rows - cols) > theiler
        rows = rows[mask_t]; cols = cols[mask_t]; dists = dists[mask_t]
        order = np.argsort(dists)
        d_sorted = dists[order]
        pair_counts = np.searchsorted(d_sorted, r_vals, side="right").astype(float)

    C = (2.0 * pair_counts) / (N * (N - 1))
    log_r = np.log(r_vals)
    log_C = np.log(C + 1e-300)


    if auto_window:
        best = {"R2": -np.inf}
        for w in range(max(window_min, 5), max(window_min, 5) + 8):
            for i in range(0, len(r_vals) - w + 1):
                x = log_r[i:i+w].reshape(-1, 1)
                y = log_C[i:i+w]
                reg = LinearRegression().fit(x, y)
                R2 = r2_score(y, reg.predict(x))
                if R2 > best["R2"]:
                    best = {"R2": R2, "slope": float(reg.coef_[0]),
                            "lo": i, "hi": i+w, "reg": reg}
        D2 = best["slope"]; lo, hi = best["lo"], best["hi"]; reg = best["reg"]
        fit_info = {"mode": "auto_window", "R2": best["R2"], "lo": lo, "hi": hi}
    else:
        lo = int(np.floor(trim_frac * len(r_vals)))
        hi = int(np.ceil((1.0 - trim_frac) * len(r_vals)))
        if hi - lo < 5:
            raise ValueError("too few points for fitting, increase n_r or decrease trim_frac")
        x = log_r[lo:hi].reshape(-1, 1)
        y = log_C[lo:hi]
        reg = LinearRegression().fit(x, y)
        D2 = float(reg.coef_[0])
        fit_info = {"mode": "trim", "R2": r2_score(y, reg.predict(x)), "lo": lo, "hi": hi}

    if return_debug:
        return D2, {"r_vals": r_vals, "C": C, "log_r": log_r, "log_C": log_C,
                    "fit_slice": (fit_info["lo"], fit_info["hi"]),
                    "reg": reg, "fit_info": fit_info}
    return D2



def compute_D2_from_excel(path, usecols=("x","y","z"),
                          n_r=40, theiler=0, auto_window=True, window_min=6,
                          random_state=0):
    try:
        df = pd.read_excel(path)
        x = df[usecols[0]].to_numpy()
        y = df[usecols[1]].to_numpy()
        z = df[usecols[2]].to_numpy()
        data = np.array((x, y, z))
        D2 = corr_dim_3d(data, n_r=n_r, theiler=theiler,
                         auto_window=auto_window, window_min=window_min,
                         return_debug=False, random_state=random_state)
        return D2
    except Exception as e:
        return 0


def compute_batch_parallel(paths, n_r=40, theiler=0, auto_window=True, window_min=6,
                           max_workers=None, base_seed=1234):

    if max_workers is None:
        mw = max(os.cpu_count() - 1, 1)
    else:
        mw = max_workers

    results = np.full(len(paths), np.nan, dtype=float)
    with ProcessPoolExecutor(max_workers=mw) as ex:
        fut2idx = {}
        for idx, p in enumerate(paths):
            rs = base_seed + idx * 997
            fut = ex.submit(compute_D2_from_excel, p,
                            n_r=n_r, theiler=theiler,
                            auto_window=auto_window, window_min=window_min,
                            random_state=rs)
            fut2idx[fut] = idx
        for fut in as_completed(fut2idx):
            i = fut2idx[fut]
            try:
                results[i] = fut.result()
            except Exception:
                results[i] = 0
    return results


def psrc_paths(a, n):
    base = r"C:/Users/Lenovo/Desktop/PastState/Lorenz/NewPrediction/Data/DifferentWarmUp/long/data"
    return [f"{base}/times{i}.xlsx" for i in range(a, a+n)]

def rc_paths(a, n):
    base = r"C:/Users/Lenovo/Desktop/RC/Lorenz/Data/long/data"
    return [f"{base}/times{i}.xlsx" for i in range(a, a+n)]

if __name__ == "__main__":

    ps_paths = psrc_paths(a=0, n=1000)
    rc_paths = rc_paths(a=0, n=1000)
    #Fixed hyper↑
    #Random hyper: a=1000, n=2000

    d_psrc = compute_batch_parallel(ps_paths, n_r=40, theiler=0, auto_window=True, window_min=6)
    d_trrc = compute_batch_parallel(rc_paths, n_r=40, theiler=0, auto_window=True, window_min=6)


    np.save(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/D_lorenz_psrc", d_psrc)
    np.save(r"C:/Users/Lenovo/Desktop/PastState/Lorenz/D_lorenz_rc", d_trrc)



    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharey=True)

    axes[0].hist(d_psrc, bins=30, color='royalblue', edgecolor='black', alpha=0.7)
    axes[0].set_title("DBRC")
    axes[0].set_xlabel("D₂ value")
    axes[0].set_ylabel("Counts")
    axes[0].grid(alpha=0.3)

    axes[1].hist(d_trrc, bins=30, color='darkorange', edgecolor='black', alpha=0.7)
    axes[1].set_title("TRRC")
    axes[1].set_xlabel("D₂ value")
    axes[1].grid(alpha=0.3)

    fig.suptitle("Distribution of correlation dimension D₂", fontsize=14)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()
    #plt.savefig()
