import os
import time
import numpy as np
import pandas as pd
import igraph as ig
from numba import njit
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed


d = 3
n = 200

gamma = 0.06
alpha = 0.13
beta = 10 ** (-7)

length = 10
thr = 0.2


data = pd.read_excel(
    r"C:/Users/Lenovo/Desktop/PastState/Lorenz/Prediction/Lorenz.xlsx",
    engine="openpyxl"
)
T = data["time"].to_numpy()
X = data["x"].to_numpy()
Y = data["y"].to_numpy()
Z = data["z"].to_numpy()

idx0 = int((length-5) / 0.01)

t_ini = T[:idx0]
x_ini = X[:idx0]
y_ini = Y[:idx0]
z_ini = Z[:idx0]

t_train = T[idx0 - 1: idx0 + 4500] / 1.014
x_train = X[idx0 - 1: idx0 + 4500]
y_train = Y[idx0 - 1: idx0 + 4500]
z_train = Z[idx0 - 1: idx0 + 4500]

t_test = (T[idx0 + 4500: idx0 + 5514] - T[idx0 + 4500]) / 1.014
x_test = X[idx0 + 4500: idx0 + 5514]
y_test = Y[idx0 + 4500: idx0 + 5514]
z_test = Z[idx0 + 4500: idx0 + 5514]

V = np.array([x_train, y_train, z_train])
V1 = np.array([x_ini, y_ini, z_ini])


rho_list = np.linspace(0, 3, 150)          # delta_rho ≈ 0.02
poss_list = np.linspace(0.001, 0.999, 50)  # d_poss ≈ 0.02


def generate_A(poss, rho, n=n):
    g = ig.Graph.Erdos_Renyi(n=n, p=poss)
    g.es["weight"] = np.random.normal(0.0, 1.0, len(g.es))
    A = np.array(g.get_adjacency(attribute="weight").data, dtype=np.float64)
    eigvals = np.linalg.eigvals(A)
    rhoA = np.max(np.abs(eigvals))
    A = (rho / rhoA) * A
    return A


@njit
def update(R, A, WinV, alpha_val):
    for i in range(R.shape[1] - 1):
        R[:, i + 1] = (1.0 - alpha_val) * R[:, i] + alpha_val * np.tanh(
            np.dot(A, np.ascontiguousarray(R[:, i])) + WinV[:, i]
        )
    return R



def lorenz(p, rho, n=n):

    Pred = np.zeros((d, len(t_test)))

    for times in range(500):
        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))

        Win = np.random.uniform(-gamma, gamma, (n, d))

        A = generate_A(p, rho)

        #warm up
        WinV1 = np.dot(Win, V1)
        R1 = update(R1, A, WinV1, alpha)
        R[:, 0] = R1[:, -1]

        #train
        WinV = np.dot(Win, V)
        R = update(R, A, WinV, alpha)
        r = R[:, -1]
        Wout = V @ R.T @ np.linalg.inv(R @ R.T + beta * np.eye(n))

        #prediction
        for h in range(len(t_test)):
            r = (1.0 - alpha) * r + alpha * np.tanh(np.dot(A, r) + np.dot(Win, np.dot(Wout, r)))
            Pred[:, h] += np.dot(Wout, r)

    Pred = Pred / 500

    xline = Pred[0, :]
    yline = Pred[1, :]
    zline = Pred[2, :]

    R11 = np.array([x_test, y_test, z_test])
    R22 = np.array([xline, yline, zline])
    rmse = np.sqrt(np.mean((R11 - R22) ** 2, axis=0))
    nrmse = rmse / (np.std(R11, axis=0))

    indexs = np.where(nrmse > thr)[0]

    pre_t = indexs[0] * 0.01 / 1.104

    return pre_t



if __name__ == "__main__":
    print(f"rho grid: {rho_list}")
    R_phase1 = np.zeros((len(poss_list), len(rho_list)))
    print("R_phase1 shape:", R_phase1.shape)
    tasks = []
    for j, r in enumerate(rho_list):
        for i, p in enumerate(poss_list):
            tasks.append((i, j, p, r))

    max_workers = max(1, mp.cpu_count() - 1)
    print(f"Using {max_workers} workers")

    start_all = time.time()

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_to_idx = {
            executor.submit(lorenz, p, r): (i, j, p, r)
            for (i, j, p, r) in tasks
        }

        for fut in as_completed(future_to_idx):
            i, j, p, r = future_to_idx[fut]
            try:
                pre_t = fut.result()
                R_phase1[i, j] = pre_t
                status = "OK"
            except Exception as e:
                pre_t = np.nan
                R_phase1[i, j] = pre_t
                status = f"ERROR: {e}"

            now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            print(
                f"rho={r:.4f}, p={p:.4f}, (i={i}, j={j}), pre_t={pre_t}, "
                f"status={status}, time={now}",
                flush=True,
            )

    save_path = r"C:/Users/Lenovo/Desktop/RC/Lorenz/Robustness/Phase.npy"
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    np.save(save_path, R_phase1)

    print(f"All done in {time.time() - start_all:.2f} s")
    print("Saved:", save_path)
