import numpy as np
import pandas as pd
import optuna
import igraph as ig
import networkx as nx

d = 3
n = 200

data = pd.read_excel(r"C:\Users\Lenovo\Desktop\RC\Lorenz\Prediction\Lorenz.xlsx")
T = data["time"].tolist()
X = data["x"].tolist()
Y = data["y"].tolist()
Z = data["z"].tolist()

def objective(trial):
    rho = trial.suggest_float("rho", -3, 3, step=0.01)
    gamma = trial.suggest_float("gamma", 0, 3, step=0.01)
    alpha = trial.suggest_float("alpha", 0, 1, step=0.01)
    poss = trial.suggest_float("poss", 0, 1, step=0.01)
    beta = trial.suggest_int("beta", -8, -3)
    # hyperparameter space, belta here is the index
    Loss = 0

    t_ini = T[:500]
    x_ini = X[:500]
    y_ini = Y[:500]
    z_ini = Z[:500]
    t_train = T[499:5000]
    x_train = X[499:5000]
    y_train = Y[499:5000]
    z_train = Z[499:5000]
    t_test = T[5000:5520]
    x_test = X[5000:5520]
    y_test = Y[5000:5520]
    z_test = Z[5000:5520]
    V1 = np.array([x_ini,y_ini,z_ini])
    V = np.array([x_train, y_train, z_train])

    for k in range(10):
        R = np.zeros((n, len(t_train)))
        R1 = np.zeros((n, len(t_ini)))
        loss = 0

        Win = np.random.uniform(-gamma, gamma, (n, d))
        A = nx.erdos_renyi_graph(n, poss, seed=1223)
        for (u, v) in A.edges():
            A.edges[u, v]['weight'] = np.random.normal(0, 1)
        A = nx.adjacency_matrix(A).todense()
        rhoA = max(np.linalg.eig(A)[0])
        A = (rho / abs(rhoA)) * A
        # rc initial Win r A R V U

        WinV1 = np.dot(Win, V1)
        for h in range(len(t_ini) - 1):
            R1[:, h + 1] = (1 - alpha) * R1[:, h] + \
                           alpha * np.tanh(np.dot(A, R1[:, h]) + WinV1[:, h])
        R[:, 0] = R1[:, -1]
        # initialize phase

        WinV = np.dot(Win, V)
        for i in range(len(t_train) - 1):
            R[:, i + 1] = (1 - alpha) * R[:, i] + \
                          alpha * np.tanh(np.dot(A, R[:, i]) + WinV[:, i])
        r = R[:, -1]
        Wout = np.dot(np.dot(V, np.transpose(R)),
                      np.linalg.inv(np.dot(R, np.transpose(R)) + beta * np.eye(n)))
        # train phase

        for j in range(len(t_test)):
            r = (1 - alpha) * r + alpha * np.tanh(np.dot(A, r) + \
                                                  np.dot(Win, np.dot(Wout, r)))
            pred = np.dot(Wout, r)
            loss = loss + (x_test[j] - pred[0]) ** 2 + (y_test[j] - pred[1]) ** 2 \
                   + (z_test[j] - pred[2]) ** 2

        Loss = Loss + (loss / len(t_test)) ** 0.5

    Loss = Loss / 10

    return Loss

for k in range(10):
    study = optuna.create_study(study_name="NormalRC", direction="minimize")
    study.optimize(objective, n_trials=100)
    with open(r"C:\Users\Lenovo\Desktop\RC\Lorenz\Prediction\hyper.txt", "a") as f:
        print(study.best_params, study.best_value, file=f)

