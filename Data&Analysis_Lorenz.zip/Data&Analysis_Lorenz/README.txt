Scripts for the study: "Improve the prediction stability of reservoir computing by means of dynamic structural bias" by  Jieyi Liu, Kaiwen Jiang, Jingfang Fan and Yong Zou.


abstract: 

Optimization of computational efficiency and improving predictive stability remain key challenges in reservoir computing (RC) research. Building on the principle of Poincar\'e recurrence theorem, we propose a dynamic structural bias RC algorithm, significantly improving the prediction stability. Our framework refines the conventional training process by introducing a two-step mechanism. First, a reference state library is constructed from the training time series. Second, this library is used in conjunction with a dot-product similarity calculation to generate a structural, dynamic bias term. This dynamic bias introduces high-fidelity historical information into the reservoir's state update equation. The benefit is that the bias in the prediction phase acts as a dynamic constraint guiding the reservoir evolution toward the true known trajectory. We prove that our algorithm enhances the model's ability to maintain generalized synchronization with the target system's attractor in the autonomous prediction phase. Consequently, our method achieves two key advantages: predictive stability is dramatically improved, and the model's sensitivity to network hyperparameters is reduced. We demonstrate the effectiveness of our method through the reconstruction and long-term prediction of various chaotic systems, showing a substantially increased prediction horizon and a more stable, faithful reproduction of the attractor's structural geometry. 

Files are organized as follows: 
- DBRC_
	-- Mechnism_Fig. 12a, Fig. 13a
	-- Prediction 
		--- ShortPrediction_Fig. 5ae
		--- PhaseDiagram_Fig. 6a
		--- DifferentSimilarity_Fig. 7a
		--- DifferentRSLength_Fig. 8a
		--- DifferentBias_Fig. 9a
		--- LongPrediction_Fig. 10ab

- TRRC_
	-- ShortTimePrediction_Fig5. ae, Fig7. a, Fig8. a, Fig9. a
	-- PhaseDiagram_Fig6. a
	-- LongTimePrediction_Fig10. ab


